DELETE FROM ratings
WHERE rating_id>10
LIMIT 1000;

DELETE FROM ratings
WHERE rating_id>10
LIMIT 10000;

DELETE FROM ratings
WHERE rating_id>10
LIMIT 100000;