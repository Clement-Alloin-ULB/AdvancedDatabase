SELECT title
FROM ratings
WHERE genre_name = 'Adventure' AND rating >= 4;


SELECT
    AVG(CASE WHEN genre_name = 'Comedy' THEN rating END) AS mean_rating_comedy
FROM ratings
WHERE
    genre_name IN ('Comedy');