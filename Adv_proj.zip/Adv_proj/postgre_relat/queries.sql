SELECT m.title
FROM movie m
JOIN genre g ON m.genre_id = g.genre_id
JOIN ratings r ON m.movie_id = r.movie_id
WHERE g.genre_name = 'Adventure' AND r.rating >= 4;


SELECT
    AVG(CASE WHEN g.genre_name = 'Comedy' THEN r.rating END) AS mean_rating_comedy
FROM
    movie m
    JOIN genre g ON m.genre_id = g.genre_id
    JOIN ratings r ON m.movie_id = r.movie_id
WHERE
    g.genre_name IN ('Comedy');